import React from 'react';
import { Recipe } from '../services/gemini';
import { motion } from 'motion/react';
import { ChefHat, Utensils, Info } from 'lucide-react';

interface RecipeCardProps {
  recipe: Recipe;
  index: number;
}

export const RecipeCard: React.FC<RecipeCardProps> = ({ recipe, index }) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.1 }}
      className="bg-white rounded-3xl overflow-hidden border border-slate-100 recipe-card-shadow group"
    >
      <div className="relative aspect-square overflow-hidden bg-slate-50">
        {recipe.imageUrl ? (
          <img
            src={recipe.imageUrl}
            alt={recipe.name}
            className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
            referrerPolicy="no-referrer"
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center text-slate-300">
            <Utensils size={48} strokeWidth={1} />
          </div>
        )}
        <div className="absolute top-4 left-4">
          <span className={`px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider ${
            recipe.type === 'meat' ? 'bg-orange-100 text-orange-600' : 
            recipe.type === 'vegetable' ? 'bg-emerald-100 text-emerald-600' : 
            'bg-blue-100 text-blue-600'
          }`}>
            {recipe.type === 'meat' ? '荤菜' : recipe.type === 'vegetable' ? '素菜' : '汤品'}
          </span>
        </div>
      </div>

      <div className="p-6">
        <h3 className="text-xl font-bold text-slate-800 mb-2">{recipe.name}</h3>
        <p className="text-sm text-slate-500 line-clamp-2 mb-4 italic leading-relaxed">
          “{recipe.description}”
        </p>

        <div className="space-y-4">
          <div>
            <div className="flex items-center gap-2 text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">
              <Info size={14} />
              <span>食材清单</span>
            </div>
            <div className="flex flex-wrap gap-1.5">
              {recipe.ingredients.map((ing, i) => (
                <span key={i} className="text-xs bg-slate-50 text-slate-600 px-2 py-1 rounded-md border border-slate-100">
                  {ing}
                </span>
              ))}
            </div>
          </div>

          <div>
            <div className="flex items-center gap-2 text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">
              <ChefHat size={14} />
              <span>烹饪步骤</span>
            </div>
            <ol className="space-y-2">
              {recipe.instructions.slice(0, 3).map((step, i) => (
                <li key={i} className="text-sm text-slate-600 flex gap-2">
                  <span className="text-slate-300 font-mono font-bold">{i + 1}.</span>
                  <span className="line-clamp-1">{step}</span>
                </li>
              ))}
              {recipe.instructions.length > 3 && (
                <li className="text-xs text-slate-400 italic">... 更多步骤见详情</li>
              )}
            </ol>
          </div>
        </div>
      </div>
    </motion.div>
  );
};
